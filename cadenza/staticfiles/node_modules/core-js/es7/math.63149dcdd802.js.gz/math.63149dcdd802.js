require('../modules/es7.math.iaddh');
require('../modules/es7.math.isubh');
require('../modules/es7.math.imulh');
require('../modules/es7.math.umulh');
module.exports = require('../modules/_core').Math;
