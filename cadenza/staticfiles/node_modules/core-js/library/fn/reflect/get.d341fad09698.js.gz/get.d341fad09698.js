require('../../modules/es6.reflect.get');
module.exports = require('../../modules/_core').Reflect.get;