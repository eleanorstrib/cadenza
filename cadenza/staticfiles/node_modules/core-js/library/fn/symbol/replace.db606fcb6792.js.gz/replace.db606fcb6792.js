require('../../modules/es6.regexp.replace');
module.exports = require('../../modules/_wks-ext').f('replace');