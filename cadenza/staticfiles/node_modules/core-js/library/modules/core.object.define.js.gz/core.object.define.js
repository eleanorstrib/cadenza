var $export = require('./_export')
  , define  = require('./_object-define');

$export($export.S + $export.F, 'Object', {define: define});