require('../modules/es7.system.global');
require('../modules/es7.symbol.async-iterator');
module.exports = require('./3');
