require('../modules/es7.object.get-own-property-descriptors');
require('../modules/es7.string.pad-start');
require('../modules/es7.string.pad-end');
module.exports = require('./4');
