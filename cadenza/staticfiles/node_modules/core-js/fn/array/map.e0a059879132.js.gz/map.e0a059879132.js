require('../../modules/es6.array.map');
module.exports = require('../../modules/_core').Array.map;