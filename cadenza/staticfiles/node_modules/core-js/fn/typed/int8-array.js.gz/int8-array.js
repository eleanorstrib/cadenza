require('../../modules/es6.typed.int8-array');
module.exports = require('../../modules/_core').Int8Array;