require('../../modules/es6.math.atanh');
module.exports = require('../../modules/_core').Math.atanh;