require('../../modules/es6.reflect.set');
module.exports = require('../../modules/_core').Reflect.set;