require('../../modules/es6.object.prevent-extensions');
module.exports = require('../../modules/$.core').Object.preventExtensions;