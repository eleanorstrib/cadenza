require('../../modules/es6.math.imul');
module.exports = require('../../modules/$.core').Math.imul;