require('../../modules/es6.reflect.apply');
module.exports = require('../../modules/$.core').Reflect.apply;