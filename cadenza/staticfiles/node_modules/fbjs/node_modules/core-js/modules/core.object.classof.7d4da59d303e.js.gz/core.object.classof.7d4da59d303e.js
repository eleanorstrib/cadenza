var $export = require('./$.export');

$export($export.S + $export.F, 'Object', {classof: require('./$.classof')});