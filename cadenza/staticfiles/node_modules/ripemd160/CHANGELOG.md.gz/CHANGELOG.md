0.2.0 / 2014-03-09
------------------
* removed bower.json and component.json
* changed 4 spacing to 2
* returns `Buffer` type now, input must be Array, Uint8Array, Buffer, or string
* remove deps: `convert-hex` and `convert-string`

0.1.0 / 2013-11-20
------------------
* changed package name 
* removed AMD support

0.0.2 / 2013-11-06
------------------
* fixed component.json file

0.0.1 / 2013-11-03
------------------
* initial release