If you are NOT on OS X and have come here to file an issue about compatibility problems, 
please stop and go to #115 for your answer.

You can look through many other similar closed issues as well if you're interested:
https://github.com/strongloop/fsevents/search?utf8=%E2%9C%93&q=%22notsup%22+OR+%22EBADPLATFORM%22&type=Issues.

If you are here to report an issue observed while using this module on OS X, please delete
all this pre-filled text then go ahead and submit your report.
