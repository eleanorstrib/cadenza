"use strict";

exports.__esModule = true;

exports.default = function () {};

module.exports = exports["default"];