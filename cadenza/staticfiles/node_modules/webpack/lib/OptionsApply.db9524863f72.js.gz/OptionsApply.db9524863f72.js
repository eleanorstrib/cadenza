/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
function OptionsApply() {}
module.exports = OptionsApply;

OptionsApply.prototype.process = function( /* options, compiler */ ) {

};
